def question_1():
    return "b"


def question_2():
    return "b"


def question_3():
    return "b"


def question_4():
    return "a"

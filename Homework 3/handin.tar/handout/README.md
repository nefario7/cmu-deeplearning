### Executing in Terminal

#### Please confirm you are in the following directory:

	./HW3/handout

#### To execute the autograder in terminal, please execute the following

	python autograder/hw3_autograder/runner.py

#### To execute the toy problem autograder in terminal, please execute the following

	python autograder/hw3_autograder/toy_runner.py

### Submitting to AutoLab

#### Please confirm you are in the following directory:

	./HW3

#### Run

	tar -cvf handin.tar handout/

#### Submit the handin.tar created to AutoLab
